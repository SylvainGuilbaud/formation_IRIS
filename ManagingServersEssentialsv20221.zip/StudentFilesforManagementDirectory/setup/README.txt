To run the installer, import Installer.xml into any namespace and call the RunInstall() method. RunInstall() takes 1 optional argument of the path the the student files directory. If it is not supplied, it assumes C:\Management

Do ##class(Training.MISIntro.Installer).RunInstall()