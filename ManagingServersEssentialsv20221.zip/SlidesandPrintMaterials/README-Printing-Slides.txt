For the Learner's Guide, this document shows:
* which documents to print, and how to print them, for classes in the physical classroom
* which documents to prepare PDFs for, for classes in the virtual classroom

For both physical and virtual classroom, the Learning Services training coordinator prepares the PDF, inclding the cover, using Acrobat Pro.

Printing for the physical classroom: print spiral bound, color heavy stock front cover, heavy stock back, double-sided

These are the files in order, along with the test to print in the tabs in parentheses:

* 01Overview (1. Overview)	
* 02Install (2. Installation)	
* 03Arch (3. Architecture) 	
* 04Config (4. Configuration)
* 05Jour (5. Journaling)
* 06Backup (6. Backups)
* 07Managing (7. Managing)
* 08Monitoring (8. Monitoring)
* 09TroubleshootingBasicis (9. Troubleshooting Basics)
* 10Mirroring (10. Mirroring)
* 11SecurityBasics (11. Security Basics)
* 99WhatNext (What's Next?)		
* AppendixA-Commands.doc (Appendix A: Commands)
* AppendixB-ECP.ppt (Appendix B: ECP)
* AppendixC-Shadowing.ppt (Appendix C: Shadowing)