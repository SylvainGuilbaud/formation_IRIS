For the Exercises, this document shows:
* which documents to print, and how to print them, for classes in the physical classroom
* which documents to prepare PDFs for, for classes in the virtual classroom

For both physical and virtual classroom, the Learning Services training coordinator prepares the PDF, including the cover, using Acrobat Pro.

Printing for the physical classroom: print spiral bound, color heavy stock front cover, heavy stock back, double-sided

These are the files in order, along with the test to print in the tabs in parentheses:

TABS - include the numbers and use MIXED CASE (not all caps). 
* Exercises (Exercises)		
* AnswerKey (Answer Key)