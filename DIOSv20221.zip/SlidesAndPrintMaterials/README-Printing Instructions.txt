This document serves two purposes:
* Which documents to print, and how to print them, for classes in the physical classroom
* Which documents to prepare PDFs for, and which can be provided as-is, for classes in the virtual classroom


Learner's Guide
=====================
For both physical and virtual classroom, the Learning Services training coordinator prepares the PDF using Acrobat Pro.

These are the files in order, along with the text to print in the tabs in parentheses.

* agenda.docx (Contents)
* 01Overview.pptx (1. Overview)
* 02DevIntro.pptx (2. Development Introduction)
* 03Arch.pptx (3. Architecture)
* 04Classes.pptx (4. Classes)
* 05Properties.pptx (5. Properties and Datatypes)
* 06Unit.pptx (6. Unit Testing)
* 07Collect.pptx (7. Collections and Callbacks)
* 08Relation.pptx (8. Relationships)
* 09Streams.pptx (9. Streams and Files)
* 10SQL.pptx (10. InterSystems SQL)
* 11Index.pptx (11. Indexes and Tuning)
* 99WhatNext.pptx (What's Next?)
* XAScript.pptx (Appendix A: ObjectScript Introduction)
* XBDebug.ppts (Appendix B: Debugging)
* XCObjectStorage.pptx (Appendix C: Object Storage)

ExercisesCombined
=====================
For the physical classroom: print spiral bound, color heavy stock front cover, heavy stock back, double-sided
For the virtual classroom: Learning Services training coordinator prepares the PDF using Acrobat Pro.

Other handouts
=====================
For the physical classroom: print these docs
For the virtual classroom: provide these docs as-is (no need to convert to PDF)

* HowTos.docx, double-sided and stapled
* cheat.docx, double-sided and stapled
* FCE UML.docx, double-sided and stapled (this combines FCE UML.png, FCE ERD.png, UML legend.png)
* For exercise 7-4: read instructions in README-FetchRatesMatching.docx. 
* * For the physical classroom, print FetchRatesNotes.docx and FetchRatesSnippets.docx
* * For the virtual classroom, provide FetchRatesSnippetsNumbered.docx
