Instructions for Collections Example.

Purpose: Show creating dimensions based on collection properties (array, list) of the source class.

Note: DeepSee handles $List formats as well as delimited string formats by default. Array and list collections can be handled by
providing methods to use in source expressions that convert the collections to $List (or delimited string) formats.


Files:
1. CollectionsDemo.xml contains:
	a. Transactional classes: DSF.Collections.Addres, DSF.Collections.Customer, DSF.Collections.Order, DSF.Collections.OrderItem,
	DSF.Collections.SKU
	b. Utility class: DSF.OrderUtils
	c. Cube: DSF.DSFOrdersCollectionsCube
	
Demo Overview:
1. Import CollectionsDemo.xml using Studio.
2. Populate transactional classes with data.
3. Add Collection dimensions to cube (both for arrays and lists).
4. Build cube and show in analyzer.

Note: The methods for converting the collections to $List format are provided in DSF.Collections.DSFOrdersCollectionCube

Import all classes and populate transactional classes:
1. Using studio, terminal, or management portal import and compile all classes in RelationshipDemo.xml
2. Execute the following command to populate the transactional classes:
	>Write ##class(DSF.Collections.OrderUtils).Populate()
	
Add collection dimensions to cube:

1. Open DSFOrdersCollectionCube in Architect.
2. Click Add Element -> Dimension
	 Name: OrderList (OrderArray) 
	 Element Type: Data dimension
3. Create a new Level
	Name:SKU
	Source Values: Expression ##class(DSF.Collections.DSFOrdersCollectionCube).GetOrderItemsList(%source.%ID)
							##class(DSF.Collections.DSFOrdersCollectionCube).GetOrderItemsArray(%source.%ID)
	Source value list type: $List
	
Compile and Build Cube:

1. Compile and build from Architect.

Open cube in Analyzer

1. Open DSFOrdersCollectionCube in Analzer.
2. Create some pivot tables using the dimensions corresponding to the
two collections.