Instructions for DataConnector Demonstration

Purpose: Demonstrate using DeepSee DataConnectors with link tables to make data in external databases available to DeepSee. Both versions
of the demonstration use SQL to access the data.

Files:

1. ConnectorDemo_OnGetSourceResultSet.xml: for demonstrating the use of %OnGetSourceResultSet method. File contains two classes:
	A. 
	B. 
2. ConnectorDemo_XDataQuery.xml: for demonstrating the use of the XData Query block. File contains two classes:
	A. DSF.PatientDataConnectorXData - DataConnector class
	B. DSF.XDataPatientDataCube - Cube class.
3. PatientData.mdb. An access database for use with the connectors.

High level overview of demonstration:

1. Create a Cach� link table to PatientData.
2. Import one of the above XML files.
3. Build the cube
4. Open the cube in analyzer: make some pivot tables, do some drill downs, show the detail listing.

Instructions for Creating Link table using PatientData.mdb

1. Create a DSN named PatientData.
2. Create an SQL Gateway Connection. Launch the wizard from the Management Portal (System Amdministration->Configuration->Connectivity->SQL Gateway Connections).
3. Use the gateway connection created at step 2, to create the linked table. Launch the wizard from the Management Portal (System Explorer->SQL->Link Table Wizard).

Instructions for installing the DataConnector and Cube

1. Using Studio, Terminal, or Management Portal, import one of the XML files listed above. Compile the imported classes.
2. Open the cube in Architect and compile.