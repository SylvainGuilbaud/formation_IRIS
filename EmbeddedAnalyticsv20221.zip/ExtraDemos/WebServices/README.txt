

Regards,
Joel
�Sent from Blackberry�

----- Original Message -----
From: Harry Tong [mailto:harry.tong@intersystems.com]
Sent: Friday, July 29, 2011 02:46 PM
To: Kenneth Poindexter
Cc: Wwsaleseng
Subject: How to execute MDX via Web Service

Ken:

I got following code sample from Michael Braam. It worked for my POC with a large customer.

-Harry

-----Original Message-----
From: Michael Braam [mailto:Michael.Braam@InterSystems.com]
Sent: Tuesday, January 11, 2011 7:13 AM
To: Harry Tong
Subject: AW: .NET sample - how to execute MDX

Hi Harry,

please find attached a webservice implementation to execute MDX queries. The attachment contains the service class itself plus a class DSII.ResultSet.
This is the object that is returned. A DSII.Result object has an array collection of DSII.ResultRow objects. A DSII.ResultRow object contains an array collection of DSII.ResultItems. A ResultItem represents a cell value in a pivot table. A ResultItem has a ItemColLabel and a ItemRowLabel property for the corresponding labels in the pivot and an ItemValue property which contains the cell value itself.

If you have drill-downs, the label delimiter from one level to the next is '||'.

There is one restriction. The webservice currently can only handle MDX-ResultSets with a maximum of two axises.

Hope this helps.

Best regards

Michael
