Instructions for Cube-Relationship Example.

Purpose: Show creating a one-way, one-to-many relationship between two cubes. 

Note: The value of the relationship is that the definitions of the dimensions are re-used and the facts are only built once saving database space and cube build times.

Files:
1. RelationshipDemo.xml. Contains the following class definitions:
	a. DSFOrderCube - Cube definition for the "independent" cube.
	b. DSFOrderItemCube - Cube definition for the "dependent" cube.
	c. Transactional classes: DSF.SKU, DSF.Customer, DSF.Order, DSF.OrderItem, DSF.Address
	d. Utility class for populating transactional classes: DSF.OrderUtils.

Demo Overview:
1. Install the transactional classes.
2. Populate.
3. Create the relationship.
4. Build the cubes.
5. Show in cube in analyzer.
6. Look at Fact tables.

Step-By-Step instructions:

Import all classes and populate transactional classes:
1. Using studio, terminal, or management portal import and compile all classes in RelationshipDemo.xml
2. Execute the following command to populate the transactional classes:
	>Write ##class(DSF.OrderUtils).Populate()

Create the Relationship between the two cubes.

1. Create the relationship from the DSFOrderItemCube 
2. Click Add Element -> Relationship. Here are the Relationship Details
	Name: DSFOrderCube
	Property: Order.%ID
	Cardinality: one
	RelatedCube: DSFOrderCube
3. Compile the cubes.

Build the cubes.
1. Build DSFOrderCube first and DSFOrderItemCube second.

Use the cubes:
1. Open DSFOrderItemCube in Analyzer. 
2. Create pivot tables, show drill downs, etc.

