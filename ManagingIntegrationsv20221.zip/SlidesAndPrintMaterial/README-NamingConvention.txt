File names starting with:
-100s - Overview module, and possibly other supporting modules in the future
-200s - Developing Healthcare Integrations and Building System Integrations modules. Modules that end in 0 are shared, modules that end in 3 are unique to Developing Healthcare Integrations, and modules that end in a 5 are unique to Developing System Integrations.
-300s - HL7 Modules. Modules ending in 0 are shared amongst all HL7 classes. Modules ending in 4 are unique to HL7 3-Day class, modules ending in 7 are unique to Developing Healthcare Integrations
-400s - unique to Managing Integrations
-600s - Files for Building and Managing (HL7 5-Day), HL7 3-Day, Developing Healthcare Integrations, and Managing Integrations. Shared modules end in a 0, files ending in 5 are unique to Building and Managing (5-Day), files ending in 7 are shared between all HL7 classes, and files ending in a 9 are unique to Managing Integrations.
-700s - unique to Managing Integrations
-800s - Files for Developing System Integrations, and BusProdModel, which is a shared module for Healthcare and System, which ends in a 5.
-1000s - what's next module and possibly others in the future
-1100s - Appendices shared by multiple classes