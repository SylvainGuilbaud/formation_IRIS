For the Learner's Guide, this document shows:
* which documents to print, and how to print them, for classes in the physical classroom
* which documents to prepare PDFs for, for classes in the virtual classroom

For both physical and virtual classroom, the Learning Services training coordinator prepares the PDF, inclding the cover, using Acrobat Pro.

Printing for the physical classroom: print spiral bound, color heavy stock front cover, heavy stock back, double-sided

IMPORTANT: Modules 1-19 and Appendices use HANDOUT layout (2 slides per page). Modules 20-27 use NOTES layout.

These are the files in order, along with the text to print in the tabs in parentheses:

* 01Overview (1. Overview)	
* 02Install (2. Installation)	
* 03Arch (3. Architecture) 	
* 04Licensing (4. Licensing)
* 05ConfigSystem (5. System Configuration)
* 06ConfigApp (6. Application Configuration)	
* 07Apps (7. Applications)
* 08Jour (8. Journaling)
* 09Backup (9. Backup)
* 10ManagingDatabases (10. Managing Databases)
* 11ManagingProcesses (11. Managing Processes)
* 12LogReview (12. Reviewing Logs)
* 13Auditing (13. Auditing )
* 14Monitoring (14. System Monitoring)
* 15TroubleshootingBasicis (15. Troubleshooting Basics)
* 16Automation (16. Automation and Utilities)	
* 17ECP (17. ECP)
* 18Mirroring (18. Mirroring)
* 19Encryption (19. Encryption)
* 20SecurityInstall (20. Security Installation)
* 21Authentication (21. Authentication)
* 22Authorization-Basic (22. Authorization: Basics)
* 23Authorization-Svc (23. Authorization: Svc/Res)
* 24Authorization-Apps (24. Authorization: Apps)
* 25Authorization-AllTogether (25. Authorization: Together)
* 26Administration (26. Security Administration)
* 27SQLSecurity (27. SQL Security)
* 99WhatNext (What's Next?)		
* AppA-Commands.doc (Appendix A - Commands)
* AppB-Block.ppt (Appendix B - Block Structure)
* AppC-Shadowing.ppt (Appendix C - Shadowing)