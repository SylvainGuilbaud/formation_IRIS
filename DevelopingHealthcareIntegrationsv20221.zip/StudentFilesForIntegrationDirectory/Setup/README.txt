﻿
Quick summary of what it does:

1) Creates the Namespace and Database TRAINING and TRAINING2, protected by %DB_TRAINING resource

For the TRAINING namespace:

2) Imports nonHL7 related samples including: Cinema, Loan, RecordMap, RecordMapBatch, Sample, and Workflow

3) If healthcare edition, imports ComplexMap, Dashboard, DICOM, HL7, HL7v3, REST, X12

4) Populates data for Cinema and Sample. Completes post install routine for HL7v3



Can be run on UNIX or Windows


******************************************



To Use:

1) Import and compile Installer.xml into any namespace

To do so, from the InterSystems Launcher in your system tray, choose Terminal. If necessary, login with the username SuperUser and password SYS. Enter the following line of code.

do $system.OBJ.Load("C:\Integration\Setup\Installer.xml", "ck")

2) Call the Install() method, passing in the path to the Student Files folder. 

Do ##class(Training.Integration.Installer).Install("C:\Integration")

To use on InterSystems IRIS Data Platform, call Install() with a 2nd argument of 0 to prevent importing items dependent on standards used in healthcare: HL7, DICOM and X12.

Do ##class(Training.Integration.Installer).Install("C:\Integration",0)

3) Verify the method outputs that installation was successful.


*******************************************

Other Notes:

1) Call the Uninstall method of Training.Integration.Installer to delete the namespace, database, and web app
Do ##class(Training.Integration.Installer).Uninstall()


