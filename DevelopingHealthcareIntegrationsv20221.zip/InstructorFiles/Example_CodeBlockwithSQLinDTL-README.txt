Using this file: 
You can use the information and data transformation in this file to demonstrate a code block calling out to an external
database. The included transformation gets data from the MS Access patient database. The returned data is used within the code block 
to determine the value for an HL7 property.

Contents:  
1-Steps to create SQL Gateway connection
2-Steps to create link table to MS Access Patient table
3-Data transformation using a code block to call out to a MS Access database for data. 

1-Steps to create SQL Gateway connection
a. Create a DSN to MS Access Patients database c:\Integration\PatientData.mdb (This is created by students in exercises.)
b. Create SQL Gateway connection using Mgt Portal>Configuration>SQL Gateway Connections>Create New Connection>
Complete fields and select appropriate DSN>Test connection>Save connection

2-Steps to create link table to MS Access Patient table
a. Sys Mgt Portal > SQL > Change namespace to TRAINING > Link Table Wizard > Choose your DSN > choose [null schema] for the Schema > S
Select PatientData as the table > Next button > Keep some or all of the fields > Next button > Can make all fields read only>
Next button>Make PatientID the primary key > Change New class name to HealthConnectDemo.PatientData > Finish > Close > Done
b. At this point you can browse the table using Browse SQL Schemas

3-Data transformation using a code block to call out to a MS Access database for data. 
Load this data transformation into TRAINING and show testing it
